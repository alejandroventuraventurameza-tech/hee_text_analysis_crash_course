# Datos para el curso de análisis textual

Este paquete permite cargar manualmente los datos en Google Colab. Contiene seis mensajes presidenciales completos, metadatos, páginas y 619 unidades sin etiquetas. No contiene el notebook, que se distribuirá por separado, ni requiere acceso al repositorio de investigación.

1. Descarga y conserva este ZIP.
2. En el notebook de clase, ejecuta la celda de carga manual, selecciona este ZIP y sigue las instrucciones de extracción preparadas.
3. Lee data/documentos.json para trabajar con documentos y data/unidades.csv para recuperar segmentos. El primer ejercicio manual usa solo los ejemplos A y B de data/ejemplos_manuales.csv.
4. Consulta data/diccionario_columnas.md para comprender las columnas y denominadores. Los PDF de data/originales/ y textos de data/textos_originales/ permiten comprobar citas.

Los ejemplos C a F son reservas de discusión. Los resultados de data/resultados_guardados/ sirven para recuperación después de formular predicciones; no son clasificaciones de roles. No se incluyen etiquetas ni referencias que identifiquen al presidente en la tabla de ejemplos.

Los resultados describen únicamente estos seis documentos. Sus audiencias y ocasiones difieren; normalizar por longitud no elimina esas diferencias. Las menciones por 1.000 palabras utilizan el total de palabras de texto_conteo del documento, no el conteo heredado del inventario ni el número de unidades.

Fuente documental: Museo del Congreso de la República del Perú. Las URL específicas aparecen en metadatos.csv. Las copias, unidades y procedencia se prepararon desde v1.0-ccl de la investigación de Alejandro Ventura. No se declara una licencia abierta para toda la colección. No se incluyen bibliografía protegida ni documentos personales.

SHA256SUMS.txt contiene huellas de los archivos incluidos en este paquete, excepto el propio listado. La comprobación completa de carga y ejecución en Colab se realizará con el notebook.
