# Proyecto Beamer para Overleaf

Importa este ZIP como proyecto nuevo. Selecciona 1_main.tex y el compilador XeLaTeX. La bibliografía usa Biber y estilo APA. Overleaf normalmente ejecuta Biber durante la compilación; si faltan referencias, recompila desde cero y revisa el log.

1_main.tex carga 2_preamble.tex y 3_content.tex desde la raíz. La bibliografía está en 4_bibliography.bib, el logo en images/ y la procedencia y datos en data/. No se requiere una carpeta pd01 ni acceso al repositorio de investigación.

La presentación conserva el formato 4:3 y la identidad del template original. Contiene 27 slides comunes, cuatro de consulta y tres de referencias. Las notas permanecen ocultas. Los resultados aparecen después de las actividades de predicción; el docente controla cuándo avanzar.

Dependencias de TeX: Beamer, fontspec, babel español, amsmath, amssymb, graphicx, geometry, multicol, TikZ, etoolbox, biblatex-apa con Biber e idioma español, csquotes, pgfplots y appendixnumberbeamer. El gráfico de reserva usa pgfplots con compatibilidad 1.18. No hay fuentes privadas, claves ni descargas durante la compilación.

Se revisaron estáticamente rutas, referencias, estructura y coherencia con los datos. NO se compiló localmente ni se verificó en Overleaf. Revisa allí portada, fragmento B, tabla de aplicaciones y bibliografía, además de los avisos del log. La revisión estática no prueba ausencia de desbordes ni ajuste visual.

SHA256SUMS.txt identifica los archivos incluidos, excepto el propio listado. El guion docente y los notebooks se distribuyen por separado desde el repositorio de clase.
